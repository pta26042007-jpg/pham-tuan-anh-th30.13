PHAN MEM QUAN LY SINH VIEN - JAVA ECLIPSE + SQL SERVER 2022

1. Dieu kien:
- JDK 17 tro len
- Eclipse IDE (ban co Maven)
- SQL Server 2022 va database QLSV da tao tu file SQL cua ban.

2. Mo project:
- Giai nen QuanLySinhVien.zip.
- Eclipse > File > Import > Maven > Existing Maven Projects.
- Chon thu muc QuanLySinhVien, Finish.
- Cho Maven tai Microsoft JDBC Driver.

3. Cau hinh dang nhap SQL Server:
Mo src/main/resources/db.properties va sua:
db.url=jdbc:sqlserver://localhost:1433;databaseName=QLSV;encrypt=true;trustServerCertificate=true
db.username=sa
db.password=MAT_KHAU_SQL_SERVER_CUA_BAN

Neu SQL Server dung instance/port khac localhost:1433, sua URL cho dung.
Khong gui mat khau that cho nguoi khac.

4. Chay:
Mo src/main/java/main/Main.java > Run As > Java Application.

5. Chuc nang trong ban dau:
- Hien thi danh sach sinh vien.
- Tim theo ma sinh vien/ho ten.
- Them, cap nhat, xoa sinh vien.
- Chon MaLop tu bang LOP.
- Dung PreparedStatement de tranh loi SQL injection.

6. Luu y:
- Tai khoan SQL Server phai bat SQL Server Authentication (Mixed Mode), dich vu SQL Server dang chay va TCP/IP da bat.
- Script mau cua ban co MatKhauHash='REPLACE_WITH_BCRYPT_HASH'; vi vay chua the dung cac tai khoan mau de dang nhap. Ban dau chuong trinh mo truc tiep man hinh quan ly sinh vien, chua lam dang nhap.
- Xoa sinh vien co the bi SQL Server tu choi neu sinh vien da co du lieu o DANGKY/HOCPHI/TAIKHOAN do rang buoc khoa ngoai. Day la hanh vi bao ve du lieu.
- Ngay sinh va ngay nhap hoc nhap theo dinh dang yyyy-MM-dd, vi du 2005-01-15.
