package database;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
    private static final Properties CONFIG = new Properties();

    static {
        try (InputStream input = DBConnection.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (input == null) throw new IllegalStateException("Khong tim thay file db.properties");
            CONFIG.load(input);
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    public static Connection getConnection() throws SQLException {
        String url = CONFIG.getProperty("db.url");
        String user = CONFIG.getProperty("db.username");
        String password = CONFIG.getProperty("db.password");
        return DriverManager.getConnection(url, user, password);
    }

    public static void testConnection() throws SQLException {
        try (Connection connection = getConnection()) {
            if (!connection.isValid(5)) throw new SQLException("Ket noi khong hop le");
        }
    }
}
