package model;

import java.time.LocalDate;

public class SinhVien {
    private String maSV, hoTen, gioiTinh, diaChi, soDienThoai, email, trangThai, maLop;
    private LocalDate ngaySinh, ngayNhapHoc;

    public SinhVien(String maSV, String hoTen, LocalDate ngaySinh, String gioiTinh,
            String diaChi, String soDienThoai, String email, LocalDate ngayNhapHoc,
            String trangThai, String maLop) {
        this.maSV = maSV; this.hoTen = hoTen; this.ngaySinh = ngaySinh;
        this.gioiTinh = gioiTinh; this.diaChi = diaChi; this.soDienThoai = soDienThoai;
        this.email = email; this.ngayNhapHoc = ngayNhapHoc; this.trangThai = trangThai; this.maLop = maLop;
    }
    public String getMaSV(){return maSV;} public String getHoTen(){return hoTen;}
    public LocalDate getNgaySinh(){return ngaySinh;} public String getGioiTinh(){return gioiTinh;}
    public String getDiaChi(){return diaChi;} public String getSoDienThoai(){return soDienThoai;}
    public String getEmail(){return email;} public LocalDate getNgayNhapHoc(){return ngayNhapHoc;}
    public String getTrangThai(){return trangThai;} public String getMaLop(){return maLop;}
}
