package dao;

import database.DBConnection;
import model.SinhVien;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SinhVienDAO {
    public List<SinhVien> getAll(String keyword) throws SQLException {
        String sql = "SELECT MaSV, HoTen, NgaySinh, GioiTinh, DiaChi, SoDienThoai, Email, NgayNhapHoc, TrangThai, MaLop " +
                     "FROM SINHVIEN WHERE MaSV LIKE ? OR HoTen LIKE ? ORDER BY MaSV";
        List<SinhVien> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            String key = "%" + (keyword == null ? "" : keyword.trim()) + "%";
            ps.setString(1, key); ps.setString(2, key);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(new SinhVien(
                    rs.getString("MaSV"), rs.getString("HoTen"),
                    rs.getDate("NgaySinh").toLocalDate(), rs.getString("GioiTinh"),
                    rs.getString("DiaChi"), rs.getString("SoDienThoai"), rs.getString("Email"),
                    rs.getDate("NgayNhapHoc").toLocalDate(), rs.getString("TrangThai"), rs.getString("MaLop")));
            }
        }
        return list;
    }

    public void insert(SinhVien s) throws SQLException {
        String sql = "INSERT INTO SINHVIEN(MaSV,HoTen,NgaySinh,GioiTinh,DiaChi,SoDienThoai,Email,NgayNhapHoc,TrangThai,MaLop) VALUES(?,?,?,?,?,?,?,?,?,?)";
        executeSave(sql, s, false);
    }

    public void update(SinhVien s) throws SQLException {
        String sql = "UPDATE SINHVIEN SET HoTen=?,NgaySinh=?,GioiTinh=?,DiaChi=?,SoDienThoai=?,Email=?,NgayNhapHoc=?,TrangThai=?,MaLop=? WHERE MaSV=?";
        executeSave(sql, s, true);
    }

    private void executeSave(String sql, SinhVien s, boolean update) throws SQLException {
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            if (!update) ps.setString(i++, s.getMaSV());
            ps.setString(i++, s.getHoTen()); ps.setDate(i++, Date.valueOf(s.getNgaySinh()));
            ps.setString(i++, s.getGioiTinh()); ps.setString(i++, s.getDiaChi());
            ps.setString(i++, s.getSoDienThoai()); ps.setString(i++, s.getEmail());
            ps.setDate(i++, Date.valueOf(s.getNgayNhapHoc())); ps.setString(i++, s.getTrangThai());
            ps.setString(i++, s.getMaLop());
            if (update) ps.setString(i, s.getMaSV());
            ps.executeUpdate();
        }
    }

    public void delete(String maSV) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM SINHVIEN WHERE MaSV=?")) {
            ps.setString(1, maSV); ps.executeUpdate();
        }
    }

    public List<String> getMaLopList() throws SQLException {
        List<String> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT MaLop FROM LOP ORDER BY MaLop");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(rs.getString(1));
        }
        return list;
    }
}
