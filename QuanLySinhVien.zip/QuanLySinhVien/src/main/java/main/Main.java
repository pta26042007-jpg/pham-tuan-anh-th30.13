package main;

import database.DBConnection;
import view.SinhVienFrame;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                DBConnection.testConnection();
                JOptionPane.showMessageDialog(null,"Kết nối SQL Server 2022 thành công!");
                new SinhVienFrame().setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                    "Không thể kết nối SQL Server. Hãy kiểm tra db.properties, SQL Server và TCP/IP.\n\nChi tiết: "+e.getMessage(),
                    "Lỗi kết nối",JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
