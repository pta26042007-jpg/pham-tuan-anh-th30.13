package view;

import dao.SinhVienDAO;
import model.SinhVien;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class SinhVienFrame extends JFrame {
    private final SinhVienDAO dao = new SinhVienDAO();
    private final DefaultTableModel model = new DefaultTableModel(
        new String[]{"Mã SV","Họ tên","Ngày sinh","Giới tính","Địa chỉ","Điện thoại","Email","Ngày nhập học","Trạng thái","Mã lớp"}, 0) {
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField ma = new JTextField(), ten = new JTextField(), ns = new JTextField(),
        diachi = new JTextField(), sdt = new JTextField(), email = new JTextField(),
        nnh = new JTextField(), search = new JTextField(18);
    private final JComboBox<String> gioitinh = new JComboBox<>(new String[]{"Nam","Nữ"});
    private final JComboBox<String> trangthai = new JComboBox<>(new String[]{"Đang học","Bảo lưu","Đã tốt nghiệp","Đã thôi học"});
    private final JComboBox<String> malop = new JComboBox<>();

    public SinhVienFrame() {
        setTitle("QUẢN LÝ SINH VIÊN - QLSV");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 700); setLocationRelativeTo(null);
        setLayout(new BorderLayout(10,10));
        getContentPane().setBackground(new Color(245,247,251));

        JLabel heading = new JLabel("QUẢN LÝ SINH VIÊN", SwingConstants.CENTER);
        heading.setFont(new Font("Arial",Font.BOLD,24)); heading.setForeground(new Color(30,70,130));
        heading.setBorder(BorderFactory.createEmptyBorder(15,5,5,5));
        add(heading,BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(8,8));
        center.setOpaque(false);
        JPanel form = new JPanel(new GridLayout(5,4,8,8));
        form.setBorder(BorderFactory.createTitledBorder("Thông tin sinh viên"));
        addField(form,"Mã sinh viên",ma); addField(form,"Họ tên",ten);
        addField(form,"Ngày sinh (yyyy-MM-dd)",ns); addField(form,"Giới tính",gioitinh);
        addField(form,"Địa chỉ",diachi); addField(form,"Số điện thoại",sdt);
        addField(form,"Email",email); addField(form,"Ngày nhập học (yyyy-MM-dd)",nnh);
        addField(form,"Trạng thái",trangthai); addField(form,"Mã lớp",malop);
        center.add(form,BorderLayout.NORTH);

        table.setRowHeight(25); table.setAutoCreateRowSorter(true);
        center.add(new JScrollPane(table),BorderLayout.CENTER);
        add(center,BorderLayout.CENTER);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER,8,8));
        JButton add = button("Thêm"), update = button("Cập nhật"), delete = button("Xóa"),
                clear = button("Làm mới"), reload = button("Tải danh sách");
        bottom.add(add); bottom.add(update); bottom.add(delete); bottom.add(clear); bottom.add(reload);
        bottom.add(new JLabel("Tìm kiếm:")); bottom.add(search);
        JButton find = button("Tìm"); bottom.add(find);
        add(bottom,BorderLayout.SOUTH);

        add.addActionListener(e -> save(false));
        update.addActionListener(e -> save(true));
        delete.addActionListener(e -> remove());
        clear.addActionListener(e -> clearForm());
        reload.addActionListener(e -> load(""));
        find.addActionListener(e -> load(search.getText()));
        table.getSelectionModel().addListSelectionListener(e -> { if(!e.getValueIsAdjusting()) fillForm(); });

        try { for(String x:dao.getMaLopList()) malop.addItem(x); load(""); }
        catch(SQLException ex) { showError(ex); }
    }

    private void addField(JPanel p,String label,JComponent field) {
        p.add(new JLabel(label)); p.add(field);
    }
    private JButton button(String text) {
        JButton b=new JButton(text); b.setFocusPainted(false); return b;
    }
    private void load(String key) {
        try {
            model.setRowCount(0);
            for(SinhVien s:dao.getAll(key)) model.addRow(new Object[]{
                s.getMaSV(),s.getHoTen(),s.getNgaySinh(),s.getGioiTinh(),s.getDiaChi(),
                s.getSoDienThoai(),s.getEmail(),s.getNgayNhapHoc(),s.getTrangThai(),s.getMaLop()});
        } catch(SQLException ex) { showError(ex); }
    }
    private SinhVien readForm() {
        if(ma.getText().isBlank() || ten.getText().isBlank() || email.getText().isBlank())
            throw new IllegalArgumentException("Mã sinh viên, họ tên và email không được để trống.");
        return new SinhVien(ma.getText().trim(),ten.getText().trim(),
            LocalDate.parse(ns.getText().trim()),(String)gioitinh.getSelectedItem(),
            diachi.getText().trim(),sdt.getText().trim(),email.getText().trim(),
            LocalDate.parse(nnh.getText().trim()),(String)trangthai.getSelectedItem(),
            (String)malop.getSelectedItem());
    }
    private void save(boolean update) {
        try {
            SinhVien s=readForm();
            if(update) dao.update(s); else dao.insert(s);
            JOptionPane.showMessageDialog(this,update?"Cập nhật thành công!":"Thêm sinh viên thành công!");
            load(""); clearForm();
        } catch(Exception ex) { showError(ex); }
    }
    private void remove() {
        int row=table.getSelectedRow();
        if(row<0) { JOptionPane.showMessageDialog(this,"Hãy chọn sinh viên cần xóa."); return; }
        String id=(String)table.getValueAt(table.convertRowIndexToModel(row),0);
        if(JOptionPane.showConfirmDialog(this,"Bạn chắc chắn muốn xóa "+id+"?","Xác nhận",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {
            try { dao.delete(id); load(""); clearForm(); }
            catch(SQLException ex) { showError(ex); }
        }
    }
    private void fillForm() {
        int row=table.getSelectedRow(); if(row<0)return;
        row=table.convertRowIndexToModel(row);
        ma.setText(String.valueOf(model.getValueAt(row,0))); ma.setEditable(false);
        ten.setText(String.valueOf(model.getValueAt(row,1))); ns.setText(String.valueOf(model.getValueAt(row,2)));
        gioitinh.setSelectedItem(model.getValueAt(row,3)); diachi.setText(String.valueOf(model.getValueAt(row,4)));
        sdt.setText(String.valueOf(model.getValueAt(row,5))); email.setText(String.valueOf(model.getValueAt(row,6)));
        nnh.setText(String.valueOf(model.getValueAt(row,7))); trangthai.setSelectedItem(model.getValueAt(row,8));
        malop.setSelectedItem(model.getValueAt(row,9));
    }
    private void clearForm() {
        ma.setEditable(true); ma.setText(""); ten.setText(""); ns.setText("");
        diachi.setText(""); sdt.setText(""); email.setText(""); nnh.setText("");
        if(malop.getItemCount()>0)malop.setSelectedIndex(0);
        gioitinh.setSelectedIndex(0); trangthai.setSelectedIndex(0); table.clearSelection();
    }
    private void showError(Exception ex) {
        JOptionPane.showMessageDialog(this,ex.getMessage(),"Lỗi",JOptionPane.ERROR_MESSAGE);
    }
}
